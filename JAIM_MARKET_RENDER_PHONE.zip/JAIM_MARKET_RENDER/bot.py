import asyncio
from aiogram import Bot,Dispatcher
from aiogram.filters import Command
from aiogram.types import Message,InlineKeyboardMarkup,InlineKeyboardButton,WebAppInfo
import config
from app.db import db,ensure_user

async def main():
    if not config.BOT_TOKEN or config.BOT_TOKEN.startswith('PUT_'): raise RuntimeError('Укажи BOT_TOKEN в config.py')
    x=await db(); await x.close()
    bot=Bot(config.BOT_TOKEN); dp=Dispatcher()
    def kb():
        u=config.MINIAPP_URL.rstrip('/')+'/'
        return InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text='🛍 Открыть JAIM MARKET',web_app=WebAppInfo(url=u))],
            [InlineKeyboardButton(text='🤝 Создать сделку',web_app=WebAppInfo(url=u+'?screen=deal'))],
            [InlineKeyboardButton(text='💰 Баланс',web_app=WebAppInfo(url=u+'?screen=balance'))],
            [InlineKeyboardButton(text='📋 Мои сделки',web_app=WebAppInfo(url=u+'?screen=deals'))],
            [InlineKeyboardButton(text='🛟 Поддержка',url=config.SUPPORT_URL)]])
    @dp.message(Command('start'))
    async def start(m:Message):
        await ensure_user({'id':m.from_user.id,'username':m.from_user.username,'first_name':m.from_user.first_name,'last_name':m.from_user.last_name})
        await m.answer('<b>JAIM MARKET</b>\n\nБезопасные сделки и Marketplace прямо внутри Telegram.\nКомиссия: 1%\nРаботаем 24/7',reply_markup=kb(),parse_mode='HTML')
    @dp.message(Command('workerJAIM'))
    async def worker_cmd(m:Message):
        if m.from_user.id not in config.ADMINS+config.WORKERS: return await m.answer('⛔ Доступ закрыт')
        u=config.MINIAPP_URL.rstrip('/')+'/?screen=worker'
        await m.answer('🛠 <b>JAIM WORKER</b>',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Открыть Worker Panel',web_app=WebAppInfo(url=u))]]),parse_mode='HTML')
    @dp.message(Command('admin'))
    async def admin_cmd(m:Message):
        if m.from_user.id not in config.ADMINS: return await m.answer('⛔ Доступ закрыт')
        u=config.MINIAPP_URL.rstrip('/')+'/?screen=admin'
        await m.answer('👑 <b>JAIM ADMIN</b>',reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='Открыть Admin Panel',web_app=WebAppInfo(url=u))]]),parse_mode='HTML')
    await dp.start_polling(bot)
if __name__=='__main__': asyncio.run(main())
