# JAIM MARKET — Telegram Mini App ($0, с телефона)

Это версия для **Telegram Mini App**, которая открывается внутри Telegram по кнопке **Open App**.
Отдельный пользовательский сайт не нужен. Для Telegram технически используется HTTPS-адрес Render.

## Что тебе нужно

### 1. Telegram API
В `config.py`:

```python
API_ID = 12345678
API_HASH = "твой_api_hash"
```

Берутся на `my.telegram.org` → **API development tools**.

### 2. BotFather

```python
BOT_TOKEN = "твой_bot_token"
```

Берётся у `@BotFather`.

### 3. Админ

```python
ADMINS = [123456789]
```

Вместо `123456789` поставь свой числовой Telegram ID.

### 4. WORKERS
Если пока не нужны:

```python
WORKERS = []
```

## Почему здесь нет MINIAPP_URL
Render сам выдаёт бесплатный HTTPS-адрес и передаёт его приложению как `RENDER_EXTERNAL_URL`.
Поэтому после публикации тебе **не нужно вручную угадывать или вписывать URL**.

## Запуск на Render с телефона

1. Создай бесплатный аккаунт на Render.
2. Создай GitHub-репозиторий и загрузи содержимое этой папки.
3. В Render выбери **New → Web Service** и подключи этот репозиторий.
4. Build Command:

```text
pip install -r requirements.txt
```

5. Start Command:

```text
python start.py
```

6. После Deploy Render даст адрес вида:

```text
https://jaim-market-xxxx.onrender.com
```

Mini App будет:

```text
https://jaim-market-xxxx.onrender.com/miniapp/
```

7. Открой `@BotFather` → настройки бота → **Mini App** → **Enable Mini App**.
8. Вставь этот `/miniapp/` URL.

## Важно

- Бесплатный Render может усыплять сервис после простоя.
- API_HASH и BOT_TOKEN никому не отправляй.
- Тестовый баланс в проекте не является реальными деньгами.
- Реальные Stars/TON/карты требуют отдельной платёжной интеграции.
