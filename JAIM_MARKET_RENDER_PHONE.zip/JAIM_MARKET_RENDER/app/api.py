import hashlib,hmac,json,secrets,urllib.parse
from pathlib import Path
from fastapi import FastAPI,Header,HTTPException,UploadFile,File
from fastapi.responses import FileResponse
from pydantic import BaseModel
import config
from app.db import ensure_user,one,many,run

app=FastAPI(title='JAIM MARKET Telegram Mini App')
ROOT=Path(__file__).resolve().parent.parent
MINI=ROOT/'miniapp'; MEDIA=MINI/'media'; MEDIA.mkdir(parents=True,exist_ok=True)

def telegram_user(raw):
    if not raw: raise HTTPException(401,'Telegram Mini App data required')
    try:
        q=dict(urllib.parse.parse_qsl(raw,keep_blank_values=True)); got=q.pop('hash')
        check='\n'.join(f'{k}={q[k]}' for k in sorted(q))
        secret=hmac.new(b'WebAppData',config.BOT_TOKEN.encode(),hashlib.sha256).digest()
        good=hmac.new(secret,check.encode(),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(good,got): raise ValueError('bad hash')
        return json.loads(q['user'])
    except Exception as e: raise HTTPException(401,f'Invalid initData: {e}')
async def auth(h):
    u=telegram_user(h); await ensure_user(u); return u
def worker(uid): return uid in config.ADMINS or uid in config.WORKERS
def admin(uid): return uid in config.ADMINS

class Deal(BaseModel):
    role:str; item_type:str; title:str; description:str=''; quantity:float=1; price:float; currency:str; requisites:str=''; extra_conditions:str=''
class Action(BaseModel): action:str
class Product(BaseModel):
    title:str; item_type:str; description:str=''; media:str=''; price:float; currency:str; quantity:float=1
class Issue(BaseModel): amount:int
class TestBal(BaseModel): currency:str; amount:float

@app.get('/')
async def root(): return FileResponse(MINI/'index.html')
@app.get('/miniapp/')
async def mini(): return FileResponse(MINI/'index.html')
@app.get('/miniapp/{file}')
async def static(file:str):
    p=MINI/Path(file).name
    if not p.exists(): raise HTTPException(404)
    return FileResponse(p)
@app.get('/miniapp/media/{file}')
async def media(file:str):
    p=MEDIA/Path(file).name
    if not p.exists(): raise HTTPException(404)
    return FileResponse(p)

@app.get('/api/me')
async def me(x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    return {'user':u,'profile':await one('SELECT * FROM users WHERE id=?',(u['id'],)),'balances':await many('SELECT currency,amount FROM balances WHERE user_id=?',(u['id'],)),'worker':worker(u['id']),'admin':admin(u['id'])}

@app.get('/api/deals')
async def deals(x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    return await many('SELECT * FROM deals WHERE seller_id=? OR buyer_id=? OR creator_id=? ORDER BY id DESC',(u['id'],u['id'],u['id']))

@app.post('/api/deals')
async def create(d:Deal,x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    if d.price<=0 or d.quantity<=0 or d.currency not in ('RUB','UAH','TON','STARS'): raise HTTPException(400,'Проверь цену, количество и валюту')
    code='JAIM-'+str(secrets.randbelow(900000)+100000)
    seller=u['id'] if d.role=='seller' else None; buyer=u['id'] if d.role=='buyer' else None
    status='Ожидает покупателя' if seller else 'Ожидает продавца'
    i=await run('INSERT INTO deals(deal_code,seller_id,buyer_id,creator_id,item_type,title,description,quantity,price,currency,requisites,extra_conditions,status,fee_percent) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(code,seller,buyer,u['id'],d.item_type,d.title,d.description,d.quantity,d.price,d.currency,d.requisites,d.extra_conditions,status,config.FEE_PERCENT))
    await run('INSERT INTO deal_events(deal_id,actor_id,event) VALUES(?,?,?)',(i,u['id'],'Создана'))
    return await one('SELECT * FROM deals WHERE id=?',(i,))

@app.get('/api/deals/{i}')
async def getdeal(i:int,x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data); d=await one('SELECT * FROM deals WHERE id=?',(i,))
    if not d: raise HTTPException(404,'Сделка не найдена')
    if u['id'] not in (d['seller_id'],d['buyer_id'],d['creator_id']) and not worker(u['id']): raise HTTPException(403)
    return d

@app.post('/api/deals/{i}/action')
async def action(i:int,a:Action,x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data); d=await one('SELECT * FROM deals WHERE id=?',(i,))
    if not d or (u['id'] not in (d['seller_id'],d['buyer_id'],d['creator_id']) and not worker(u['id'])): raise HTTPException(403)
    states={'confirm_payment':'Оплата подтверждается','send_item':'Выполнение','receive':'Завершение','complete':'Завершена','cancel':'Отменена','dispute':'Спор'}
    if a.action not in states: raise HTTPException(400,'Неизвестное действие')
    s=states[a.action]; await run('UPDATE deals SET status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(s,i)); await run('INSERT INTO deal_events(deal_id,actor_id,event) VALUES(?,?,?)',(i,u['id'],a.action))
    if s=='Завершена':
        for uid in (d['seller_id'],d['buyer_id']):
            if uid: await run('UPDATE users SET deals_count=deals_count+1,turnover=turnover+? WHERE id=?',(d['price'],uid))
    return await one('SELECT * FROM deals WHERE id=?',(i,))

@app.get('/api/marketplace')
async def market(category:str='all',x_telegram_init_data:str|None=Header(None)):
    await auth(x_telegram_init_data)
    if category=='all': return await many("SELECT * FROM marketplace_items WHERE status='published' ORDER BY id DESC")
    return await many("SELECT * FROM marketplace_items WHERE status='published' AND item_type=? ORDER BY id DESC",(category,))
@app.get('/api/marketplace/{i}')
async def item(i:int,x_telegram_init_data:str|None=Header(None)):
    await auth(x_telegram_init_data); r=await one('SELECT * FROM marketplace_items WHERE id=?',(i,))
    if not r: raise HTTPException(404)
    return r
@app.post('/api/marketplace')
async def product(p:Product,x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    if not worker(u['id']): raise HTTPException(403)
    i=await run('INSERT INTO marketplace_items(seller_id,title,item_type,description,media,price,currency,quantity) VALUES(?,?,?,?,?,?,?,?)',(u['id'],p.title,p.item_type,p.description,p.media,p.price,p.currency,p.quantity))
    return await one('SELECT * FROM marketplace_items WHERE id=?',(i,))
@app.delete('/api/marketplace/{i}')
async def hide(i:int,x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    if not worker(u['id']): raise HTTPException(403)
    await run("UPDATE marketplace_items SET status='hidden' WHERE id=?",(i,)); return {'ok':True}

@app.post('/api/worker/issue-deals')
async def issue(x:Issue,x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    if not worker(u['id']) or not 1<=x.amount<=5000: raise HTTPException(400,'Допустимо 1–5000')
    await run('INSERT INTO worker_stats(user_id,test_deals) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET test_deals=test_deals+excluded.test_deals,updated_at=CURRENT_TIMESTAMP',(u['id'],x.amount)); return {'ok':True,'test_only':True}
@app.post('/api/worker/test-balance')
async def testbal(x:TestBal,x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    if not worker(u['id']) or x.currency not in ('RUB','UAH','TON','STARS') or not 0<x.amount<=1000000: raise HTTPException(400,'Некорректная тестовая сумма')
    await run('UPDATE balances SET amount=amount+? WHERE user_id=? AND currency=?',(x.amount,u['id'],x.currency)); await run('INSERT INTO balance_transactions(user_id,currency,amount,type,note) VALUES(?,?,?,?,?)',(u['id'],x.currency,x.amount,'TEST','Не реальные деньги')); return {'ok':True,'test_only':True}
@app.get('/api/worker/stats')
async def stats(x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    if not worker(u['id']): raise HTTPException(403)
    return {'test':await one('SELECT * FROM worker_stats WHERE user_id=?',(u['id'],)) or {'test_deals':0},'real':await one('SELECT COUNT(*) count,COALESCE(SUM(price),0) turnover FROM deals WHERE seller_id=? OR buyer_id=?',(u['id'],u['id']))}
@app.get('/api/admin/users')
async def users(x_telegram_init_data:str|None=Header(None)):
    u=await auth(x_telegram_init_data)
    if not admin(u['id']): raise HTTPException(403)
    return await many('SELECT * FROM users ORDER BY id DESC LIMIT 500')
@app.get('/api/config')
async def public_config():
    return {'name':'JAIM MARKET','fee':config.FEE_PERCENT,'support':config.SUPPORT_URL,'media':{k:f'/miniapp/media/{k}.png' for k in ('home','deal','market','balance','profile','withdraw','worker')}}
