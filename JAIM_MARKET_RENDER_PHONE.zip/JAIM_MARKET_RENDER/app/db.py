from pathlib import Path
import aiosqlite
from config import DATABASE

SCHEMA='''
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT, first_name TEXT, last_name TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, deals_count INTEGER DEFAULT 0, turnover REAL DEFAULT 0);
CREATE TABLE IF NOT EXISTS balances(user_id INTEGER, currency TEXT, amount REAL DEFAULT 0, PRIMARY KEY(user_id,currency));
CREATE TABLE IF NOT EXISTS balance_transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,currency TEXT,amount REAL,type TEXT,note TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS deals(id INTEGER PRIMARY KEY AUTOINCREMENT,deal_code TEXT UNIQUE,seller_id INTEGER,buyer_id INTEGER,creator_id INTEGER,item_type TEXT,title TEXT,description TEXT,quantity REAL,price REAL,currency TEXT,requisites TEXT,extra_conditions TEXT,status TEXT,fee_percent REAL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS deal_events(id INTEGER PRIMARY KEY AUTOINCREMENT,deal_id INTEGER,actor_id INTEGER,event TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS marketplace_items(id INTEGER PRIMARY KEY AUTOINCREMENT,seller_id INTEGER,title TEXT,item_type TEXT,description TEXT,media TEXT,price REAL,currency TEXT,quantity REAL,status TEXT DEFAULT 'published',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS worker_stats(user_id INTEGER PRIMARY KEY,test_deals INTEGER DEFAULT 0,test_balance REAL DEFAULT 0,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_deals_users ON deals(seller_id,buyer_id,creator_id);
CREATE INDEX IF NOT EXISTS idx_market_status ON marketplace_items(status);
'''

async def db():
    Path(DATABASE).parent.mkdir(parents=True,exist_ok=True)
    x=await aiosqlite.connect(DATABASE); x.row_factory=aiosqlite.Row
    await x.executescript(SCHEMA); await x.commit(); return x

async def ensure_user(u):
    x=await db()
    await x.execute('INSERT INTO users(id,username,first_name,last_name) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET username=excluded.username,first_name=excluded.first_name,last_name=excluded.last_name',(u['id'],u.get('username'),u.get('first_name'),u.get('last_name')))
    for c in ('RUB','UAH','TON','STARS'):
        await x.execute('INSERT OR IGNORE INTO balances(user_id,currency,amount) VALUES(?,?,0)',(u['id'],c))
    await x.commit(); await x.close()

async def one(sql,p=()):
    x=await db(); r=await x.execute(sql,p); row=await r.fetchone(); await x.close(); return dict(row) if row else None
async def many(sql,p=()):
    x=await db(); r=await x.execute(sql,p); rows=await r.fetchall(); await x.close(); return [dict(q) for q in rows]
async def run(sql,p=()):
    x=await db(); r=await x.execute(sql,p); await x.commit(); n=r.lastrowid; await x.close(); return n
