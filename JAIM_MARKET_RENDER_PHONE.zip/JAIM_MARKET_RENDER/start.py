import asyncio
import uvicorn
import config
from bot import main as bot_main

async def web_main():
    cfg = uvicorn.Config("app.api:app", host=config.HOST, port=config.PORT, log_level="info")
    server = uvicorn.Server(cfg)
    await server.serve()

async def main():
    await asyncio.gather(web_main(), bot_main())

if __name__ == "__main__":
    asyncio.run(main())
