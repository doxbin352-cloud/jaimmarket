import uvicorn,config
if __name__=='__main__': uvicorn.run('app.api:app',host=config.HOST,port=config.PORT)
