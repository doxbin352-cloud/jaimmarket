"""JAIM MARKET — единственный конфиг.

Можно задать значения прямо здесь. На Render те же параметры можно задать
через Environment Variables — тогда они имеют приоритет.
"""
import os

# ===================== TELEGRAM =====================
# 1) API_ID: my.telegram.org -> API development tools
API_ID = int(os.getenv("API_ID", "12345678"))

# 2) API_HASH: my.telegram.org -> API development tools
API_HASH = os.getenv("API_HASH", "ВСТАВЬ_API_HASH_СЮДА")

# 3) BOT_TOKEN: @BotFather -> /newbot
BOT_TOKEN = os.getenv("BOT_TOKEN", "ВСТАВЬ_BOT_TOKEN_СЮДА")

# ===================== ACCESS =====================
# Твой числовой Telegram ID
ADMINS = [int(x) for x in os.getenv("ADMINS", "123456789").split(",") if x.strip()]

# Telegram ID воркеров через запятую. Можно оставить пустым.
WORKERS = [int(x) for x in os.getenv("WORKERS", "").split(",") if x.strip()]

# ===================== MINI APP =====================
# Render сам выдаёт HTTPS-адрес. Ничего сюда вписывать не нужно.
# Если MINIAPP_URL задан вручную — используется он.
_render_url = os.getenv("RENDER_EXTERNAL_URL", "").rstrip("/")
MINIAPP_URL = os.getenv("MINIAPP_URL", (_render_url + "/miniapp/") if _render_url else "https://YOUR-RENDER-URL.onrender.com/miniapp/")

# ===================== OTHER =====================
SUPPORT_URL = os.getenv("SUPPORT_URL", "https://t.me/your_support")
HOST = "0.0.0.0"
PORT = int(os.getenv("PORT", "10000"))
DATABASE = os.getenv("DATABASE", "data/jaim_market.db")
FEE_PERCENT = float(os.getenv("FEE_PERCENT", "1.0"))
